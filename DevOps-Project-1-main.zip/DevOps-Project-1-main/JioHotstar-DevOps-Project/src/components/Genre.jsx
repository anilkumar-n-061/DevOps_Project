import React from 'react'
import './Genre.css'
function Genre() {
  return (
    <div>
        <div className="rowjj">
            <div>
                <img src="https://img10.hotstar.com/image/upload/f_auto,q_90,w_640/sources/r1/cms/prod/7015/1743070057015-i" alt="" />
            </div>
            <div>
                <img src="https://img10.hotstar.com/image/upload/f_auto,q_90,w_640/sources/r1/cms/prod/5314/1742813485314-i" alt="" />
            </div>
            <div>
                <img src="https://img10.hotstar.com/image/upload/f_auto,q_90,w_3840/sources/r1/cms/prod/5128/1741762985128-i" alt="" />
            </div>
            <div>
                <img src="https://img10.hotstar.com/image/upload/f_auto,q_90,w_640/sources/r1/cms/prod/9929/1741139529929-v" alt="" />
            </div>
            <div>
                <img src="https://img10.hotstar.com/image/upload/f_auto/sources/r1/cms/prod/5132/1741675855132-t" alt="" />
            </div>
            <div>
                <img src="https://img10.hotstar.com/image/upload/f_auto,q_90,w_640/sources/r1/cms/prod/5160/1741341265160-i" alt="" />
            </div>
            <div>
                <img src="https://img10.hotstar.com/image/upload/f_auto,q_90,w_3840/sources/r1/cms/prod/1220/1742364441220-i" alt="" />
            </div>
            <div>
                <img src="https://img10.hotstar.com/image/upload/f_auto,q_90,w_1920/sources/r1/cms/prod/5302/1535302-a-e90748391e0d" alt="" />
            </div>
            <div>
                <img src="https://img10.hotstar.com/image/upload/f_auto,q_90,w_1920/sources/r1/cms/prod/5250/1535250-a-b320bf06458d" alt="" />
            </div>
            <div>
                <img src="https://img10.hotstar.com/image/upload/f_auto,q_90,w_1920/sources/r1/cms/prod/5295/1535295-a-6a74b60243b1" alt="" />
            </div> 
            <div>
                <img src="https://img10.hotstar.com/image/upload/f_auto,q_90,w_1920/sources/r1/cms/prod/8791/1568791-a-e50a43088a1a" alt="" />
            </div>
        </div>


    </div>
  )
}

export default Genre